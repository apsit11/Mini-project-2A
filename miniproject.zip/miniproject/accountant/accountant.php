<!-- 
    ********************
    
    THIS PAGE HERE CONTAINS THE LANDING PAGE OF ACCOUNTANT

    ********************
  -->
<?php 
include '../config/config.php';
include '../essentials/header.php';
// include '../essentials/sessions.php';


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paysleep_accountant</title>

    <!-- custom css file link  -->
    <link rel="stylesheet" href="../css/styles1.css">
    
</head>
<body>
    

    <div class="wel-container">

   <div class="content">
      <h3>Hi, <span style="color:#333"><?php echo $_SESSION['name']; ?></span></h3>
      <h1>welcome</h1>
      <a href="upload.php" class="btn">Upload Excel</a>
      <a href="view.php" class="btn">View Slips</a>
   </div>

</div>
<?php 
mysqli_close($conn);
?>
</body>
</html>
