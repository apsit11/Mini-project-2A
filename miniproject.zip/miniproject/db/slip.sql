-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 25, 2023 at 09:08 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `slip_mini`
--

-- --------------------------------------------------------

--
-- Table structure for table `accountant`
--

CREATE TABLE `accountant` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accountant`
--

INSERT INTO `accountant` (`id`, `name`, `designation`, `password`) VALUES
(1, 'jayesh', 'accountant', '');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`, `designation`) VALUES
(1, 'admin', '', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `calculation`
--

CREATE TABLE `calculation` (
  `id` int(10) NOT NULL,
  `emp_id` int(10) NOT NULL,
  `days_worked` int(10) NOT NULL,
  `basic_salary` int(10) NOT NULL,
  `agp` int(10) NOT NULL,
  `cla` int(10) NOT NULL,
  `ta` int(10) NOT NULL,
  `exam_rem` int(10) NOT NULL,
  `spl_pay` int(10) NOT NULL,
  `pt` int(10) NOT NULL,
  `itax` int(10) NOT NULL,
  `add_ded` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `calculation`
--

INSERT INTO `calculation` (`id`, `emp_id`, `days_worked`, `basic_salary`, `agp`, `cla`, `ta`, `exam_rem`, `spl_pay`, `pt`, `itax`, `add_ded`) VALUES
(1, 83, 26, 1000, 6000, 300, 2400, 0, 0, 200, 1620, 0);

-- --------------------------------------------------------

--
-- Table structure for table `employee_details`
--

CREATE TABLE `employee_details` (
  `emp_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gmail` varchar(255) NOT NULL,
  `phone_no` varchar(11) NOT NULL,
  `pan_no` varchar(10) NOT NULL,
  `pf_no` varchar(25) NOT NULL,
  `uan_no` varchar(25) NOT NULL,
  `bank_acc` varchar(25) NOT NULL,
  `department` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `joining_date` date NOT NULL,
  `leaving_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee_details`
--

INSERT INTO `employee_details` (`emp_id`, `name`, `gmail`, `phone_no`, `pan_no`, `pf_no`, `uan_no`, `bank_acc`, `department`, `designation`, `role`, `joining_date`, `leaving_date`) VALUES
(1, 'Ayush Rajput', 'ayushrajput396@gmail.com', '5678941230', 'ABC1234567', 'ABC1010101010101010101', '112233445566', '111111111111111', 'COMP', 'Teaching', 'Employee', '2022-01-01', '0000-00-00'),
(2, 'Jayesh Deshmukh', 'jayesh@gmail.com', '1234567890', 'DEF1234567', 'DEF2020202020202020202', '223344556677', '222222222222222', 'COMP', 'Teaching', 'HR', '0000-00-00', NULL),
(3, 'Harshal Aponkar', 'harshal@gmail.com', '5214569870', 'GHI1234567', 'GHI3030303030303030303', '334455667788', '333333333333333', 'COMP', 'Teaching', 'Accountant', '0000-00-00', NULL),
(4, 'Pranav Mhatre', 'pranav@gmail.com', '8974562158', 'JKL1234567', 'JKL4040404040404040404', '445566778899', '444444444444444', 'COMP', 'Teaching', 'Employee', '2019-10-05', NULL),
(5, 'Samreen Chowlkar', 'samreen@gmail.com', '8745632109', 'MNO1234567', 'MNO5050505050505050505', '556677889911', '555555555555555', 'COMP', 'Teaching', 'Employee', '2019-10-06', NULL),
(6, 'Sanika Bagal', 'sanika@gmail.com', '3652147890', 'PQR1234567', 'PQR6060606060606060606', '667788991122', '666666666666666', 'COMP', 'Non Teaching', 'Employee', '2019-10-07', NULL),
(7, 'Rutuja Wagh', 'rutuja@gmail.com', '7896541230', 'STU1234567', 'STU7070707070707070707', '563214569875', '777777777777777', 'IT', 'Non Teaching', 'Employee', '2019-10-08', NULL),
(8, 'Kashish Raj', 'Kashish@gmail.com', '1234569852', 'HBG1234567', 'HGT8080808808080808080', '222266668899', '586974563215987', 'IT', 'Non Teaching', 'Employee', '2019-10-09', NULL),
(9, 'Jarjish Popo', 'popo@gmail.coom', '5263478930', 'HJN1234567', 'HNJ9090909090909099090', '959587456215', '526341526341526', 'IT', 'Non Teaching', 'Employee', '2019-10-10', NULL),
(10, 'Umesh Nehete', 'umesh@gmail.com', '5263789520', 'KJH1234567', 'KKI1234567896541230478', '523687952012', '789654123025896', 'DS', 'Teaching', 'Employee', '2019-10-11', NULL),
(11, 'Sakshi Rajshirke', 'sakshe@gmail.com', '8569856985', 'HJK1234567', 'DVG1234567891234567896', '456321789321', '526352634152638', 'AIML', 'Teaching', 'Employee', '0000-00-00', NULL),
(12, 'Alok Patil', 'alok@gmial.com', '1236547890', 'BUE1234567', 'HBN1234567896523412536', '666665545235', '123658963258963', 'COMP', 'Non Teaching', 'Employee', '0000-00-00', NULL),
(13, 'Rutul More', 'rutul@gmail.com', '5263748596', 'UJH1234567', 'KNP1234567890236526395', '123654789222', '526698745632154', 'MECH', 'Non Teaching', 'Employee', '0000-00-00', NULL),
(14, 'Pratik Rane', 'pratik@gmail.com', '5214639875', 'KLO1234567', 'ADE5369874563210236589', '123658963254', '123456789325685', 'MECH', 'Teaching', 'Employee', '0000-00-00', NULL),
(15, 'Rohit Nikumbh', 'rohit@gmail.com', '2536587412', 'AOC1234567', 'KLA1236987563259863256', '563256325632', '789654123654789', 'CIVIL', 'Non Teaching', 'Employee', '0000-00-00', NULL),
(82, 'Jayesh', 'deshmukhjayesh29@gmail.com', '9525241244', 'HIB8621926', 'ABSA2869254UIS2567120S', '722965314561', '758240212672146', 'Comps', 'Professor', '', '0000-00-00', NULL),
(83, 'Tej', 'hackur69@gmail.com', '902952152', 'HIC8621925', 'GBSA2869254UIS2567120T', '822965314565', '658240212672143', 'It', 'assistant professor\r\n ', 'Employee', '0000-00-00', NULL),
(652, 'Raj', 'raj66654@gmail.com', '9592052051', 'sajdaoisd', 'joisajd', 'ksandlk', 'dsandlk', 'AIML', 'HOD', '', '0000-00-00', NULL),
(5252, 'Super Admin', 'sa@gmail.com', '1111111111', '1111', '1111', '1111', '11111', 'dddd', 'dddd', 'SA', '0000-00-00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `resetpass`
--

CREATE TABLE `resetpass` (
  `emp_id` int(10) NOT NULL,
  `password` varchar(256) NOT NULL,
  `reset_token_hash` varchar(64) DEFAULT NULL,
  `reset_token_expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resetpass`
--

INSERT INTO `resetpass` (`emp_id`, `password`, `reset_token_hash`, `reset_token_expires_at`) VALUES
(2, 'f0d2580221200ed5a0a552890386f4d2431f765d', NULL, NULL),
(3, 'ab54d425fa8ac654e8cdf0307eebcc33ea46d08e', NULL, NULL),
(11, '7f5b0e8e3cd05c92c205989d2a6f8b4d3f0c79f6', NULL, NULL),
(12, 'd32dff82a64e4e9fae9b3e460aadfdb148ac0d4e', NULL, NULL),
(13, '501c5d41c6e1368b6bc8b00457b9fc07132b81fb', NULL, NULL),
(14, '76ab967da8cdfb5c574b9d678613e4e3963ff197', NULL, NULL),
(15, 'db7cad285b762667944f8615a3b7dce01cd67492', NULL, NULL),
(83, 'a9fee7621fec9b97c4a994c94ba51bc65409a1e4', NULL, NULL),
(1, 'e452897bce3e92aee805cb924f2f95021ba5e1f0', 'a6b5f0bd604a73e9eb681e06f4778eec962a611f', '2023-10-24 12:16:03'),
(5252, 'bfe66064950d13c8cca6086b1e107571ff405e45', NULL, NULL),
(4, '4c6f87df77f4f9864d8a46aa6fe8e1f79415415e', NULL, NULL),
(5, 'd5a41f99549001dadf54ff67f7c83588bd3e8086', NULL, NULL),
(6, '30e3d3bd9cfed361be9b540e006bb34347b4cb4f', NULL, NULL),
(7, '8c48a1d649db9f4d0779c57352e507af06998cb9', NULL, NULL),
(8, 'ba79bb07283a03bf98539dd9603a1097e0c45cdb', NULL, NULL),
(9, '347494420ee46d2c967a93a3e35d37f2c70d21e7', NULL, NULL),
(10, 'fff2fcfe94cc2dcc0b7b8754f15e14ebaf1b2742', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `id` int(11) NOT NULL,
  `emp_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `basic_salary` int(100) NOT NULL,
  `agp` int(100) NOT NULL,
  `days_worked` int(100) NOT NULL,
  `actual_basic` int(100) NOT NULL,
  `actual_agp` int(100) NOT NULL,
  `basic_add_agp` int(100) NOT NULL,
  `da` int(100) NOT NULL,
  `hra` int(100) NOT NULL,
  `cla` int(100) NOT NULL,
  `ta` int(100) NOT NULL,
  `exam_rem` int(100) NOT NULL,
  `spl_pay` int(100) NOT NULL,
  `gross` int(100) NOT NULL,
  `pf` int(100) NOT NULL,
  `pt` int(100) NOT NULL,
  `i_tax` int(100) NOT NULL,
  `add_ded` int(100) NOT NULL,
  `net_salary` int(100) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`id`, `emp_id`, `name`, `designation`, `basic_salary`, `agp`, `days_worked`, `actual_basic`, `actual_agp`, `basic_add_agp`, `da`, `hra`, `cla`, `ta`, `exam_rem`, `spl_pay`, `gross`, `pf`, `pt`, `i_tax`, `add_ded`, `net_salary`, `date`) VALUES
(184, 1, 'Ayush Rajput', 'Teaching', 5, 6000, 29, 935, 5613, 6548, 10739, 1964, 300, 2400, 0, 0, 21951, 1800, 200, 1620, 0, 3000, '2023-10-01'),
(185, 2, 'Jayesh Deshmukh', 'Teaching', 1000, 6000, 29, 935, 5613, 6548, 10739, 1964, 300, 2400, 0, 0, 21951, 1800, 200, 1620, 0, 18331, '2023-10-01'),
(186, 3, 'Harshal Aponkar', 'Teaching', 1000, 6000, 29, 935, 5613, 6548, 10739, 1964, 300, 2400, 0, 0, 21951, 1800, 200, 1620, 0, 5, '2023-10-01'),
(187, 5, 'Samreen Chowlkar', 'Teaching', 1000, 6000, 29, 935, 5613, 6548, 10739, 1964, 300, 2400, 0, 0, 21951, 1800, 200, 1620, 0, 18331, '2023-10-01'),
(188, 7, 'Rutuja Wagh', 'Non Teaching', 1000, 6000, 29, 935, 5613, 6548, 10739, 1964, 300, 2400, 0, 0, 21951, 1800, 200, 1620, 0, 18331, '2023-10-01'),
(189, 8, 'Kashish Raj', 'Non Teaching', 1000, 6000, 29, 935, 5613, 6548, 10739, 1964, 300, 2400, 0, 0, 21951, 1800, 200, 1620, 0, 18331, '2023-10-01'),
(190, 9, 'Jarjish Popo', 'Non Teaching', 1000, 6000, 29, 935, 5613, 6548, 10739, 1964, 300, 2400, 0, 0, 21951, 1800, 200, 1620, 0, 18331, '2023-10-01'),
(191, 12, 'Alok Patil', 'Non Teaching', 1000, 6000, 29, 935, 5613, 6548, 10739, 1964, 300, 2400, 0, 0, 21951, 1800, 200, 1620, 0, 18331, '2023-10-01'),
(192, 14, 'Pratik Rane', 'Teaching', 1000, 6000, 29, 935, 5613, 6548, 10739, 1964, 300, 2400, 0, 0, 21951, 1800, 200, 1620, 0, 18331, '2023-10-01');

-- --------------------------------------------------------

--
-- Table structure for table `tb_data`
--

CREATE TABLE `tb_data` (
  `id` int(10) NOT NULL,
  `emp_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `age` int(100) NOT NULL,
  `country` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_data`
--

INSERT INTO `tb_data` (`id`, `emp_id`, `name`, `age`, `country`) VALUES
(67, 100, 'jayesh', 29, 'India'),
(68, 101, 'ayush', 25, 'India'),
(69, 100, 'jayesh', 29, 'India'),
(70, 101, 'ayush', 25, 'India');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accountant`
--
ALTER TABLE `accountant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `calculation`
--
ALTER TABLE `calculation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee_details`
--
ALTER TABLE `employee_details`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `resetpass`
--
ALTER TABLE `resetpass`
  ADD UNIQUE KEY `reset_token_hash` (`reset_token_hash`),
  ADD UNIQUE KEY `reset_token_expires_at` (`reset_token_expires_at`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_data`
--
ALTER TABLE `tb_data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accountant`
--
ALTER TABLE `accountant`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `calculation`
--
ALTER TABLE `calculation`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `salary`
--
ALTER TABLE `salary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=193;

--
-- AUTO_INCREMENT for table `tb_data`
--
ALTER TABLE `tb_data`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
