<?php
$conn = mysqli_connect('localhost','root','','slip_mini');
date_default_timezone_set('Asia/Kolkata');

?>