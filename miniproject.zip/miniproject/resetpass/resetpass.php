<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <title>Document</title>
</head>
<body style="padding-left:0">
<header class="header">
        <section class="flex" style="justify-content:center;">
        <h3 class="logo">A.P Shah Institute of Technology</h3>
        </section>
    </header>
<div style="margin-top:100px;" class="emp-add">
        <form action="sendpasswordreset.php" method="post">
            <h2>Forget password</h2>
            <div class="form-group">
                <input class="box" placeholder="Enter your id" type="number" id="id" name="id" required>
            </div>
       
            <div class="form-group">
                <input type="email" class="box" id="email" name="email" placeholder="Enter your email" required>
            </div>
                <button class="submit" name = "forget_submit" type="submit">Send</button>

        </form>
    </div>
</body>
</html>