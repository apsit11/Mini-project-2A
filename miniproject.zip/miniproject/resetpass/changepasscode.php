<?php
include '../config/config.php';
session_start();
if(isset($_POST['reset_submit'])){
    $id = mysqli_real_escape_string($conn,$_POST['id']);
    $pass = mysqli_real_escape_string($conn,$_POST['pass']); 
    $cpass = mysqli_real_escape_string($conn,$_POST['cpass']);
    $token = mysqli_real_escape_string($conn,$_POST['pass_token']);
    
    if(!empty($token)){
        if(!empty($id) && !empty($pass) && !empty($cpass)){
            // Check token 
            $check_token_query = "SELECT reset_token_hash,reset_token_expires_at FROM resetpass WHERE reset_token_hash = '$token' AND emp_id='$id'";
            $check_token_query_result = mysqli_query($conn,$check_token_query);
            if(mysqli_num_rows($check_token_query_result)>0){
                $row = mysqli_fetch_assoc($check_token_query_result);

                if(strtotime($row['reset_token_expires_at']) <=date("h:i:s",time())){
                    // if token is expired
                    $_SESSION['message'] = 'Link has expired <a href="resetpass.php">Click</a> to send again';
                    header("location:changepass.php?id=$id&token=$token");
                }else{
                    if($pass==$cpass){
                        // if both the input field matches
                        if(strlen($pass)<3){
                            $_SESSION['message'] = "Password should contain more than 3 letters.";
                            header("location:changepass.php?id=$id&token=$token");

                        }else{
                            // if all conditions satisfied update the password
                            $enc_pass = sha1($pass);
                        $update_pass = "UPDATE resetpass SET password = '$enc_pass' WHERE reset_token_hash = '$token' AND emp_id='$id'";
                        $update_pass_result = mysqli_query($conn,$update_pass);

                        if($update_pass_result){
                            //after updating delete the tokne from resetpass table
                            $del_token = "UPDATE resetpass SET reset_token_hash = NULL,reset_token_expires_at = NULL WHERE emp_id = '$id'";
                            $del_token_result = mysqli_query($conn,$del_token);
                            $_SESSION['message'] = "Password updated successfully.";
                            header("location:../index.php");
                            
                        }else{
                            $_SESSION['message'] = "Couldnt update password.";
                            header("location:changepass.php?id=$id&token=$token");
    
                        }
                        }

                        
                    }else{
                        $_SESSION['message'] = "Password does not match";
                        header("location:changepass.php?id=$id&token=$token");
                    }
                }

            }else{
                $_SESSION['message'] = 'Invalid token <a href="resetpass.php">Click</a> to send again';
                header("location:changepass.php?id=$id&token=$token");
            }

        }else{
            
            $_SESSION['message'] = "Fill all the fields";
            header("location:changepass.php?id=$id&token=$token");
        }


    }else{
        $_SESSION['message'] = "Token not available";
        header('location:changepass.php');
    }
}

?>